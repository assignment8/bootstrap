package com.cts;

public interface IOrder {
	
	public void processOrder(String modelName);

}
