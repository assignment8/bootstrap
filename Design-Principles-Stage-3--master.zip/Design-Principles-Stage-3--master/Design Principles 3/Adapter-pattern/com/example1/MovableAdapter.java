package com.example1;

//Adapter Interface
public interface MovableAdapter {
	
	// returns speed in KM/H
	double getSpeed();
}
