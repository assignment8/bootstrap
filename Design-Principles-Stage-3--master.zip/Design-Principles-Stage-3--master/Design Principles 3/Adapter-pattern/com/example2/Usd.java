package com.example2;

// Original Interface
public interface Usd {

	// returns currency in USD
	double getCurr();
}
