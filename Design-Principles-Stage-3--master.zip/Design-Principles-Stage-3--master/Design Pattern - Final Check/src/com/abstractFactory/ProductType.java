package com.abstractFactory;

enum ProductType {
	ELECTRONIC, TOYS, FURNITURE;
}
