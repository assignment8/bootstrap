package com.example2;

//concrete implementation of the original interface
public class Price implements Usd {
	
	public double getCurr() {
		return 50;
	}
}
