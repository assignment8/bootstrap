package com.abstractFactory;

public enum Channel {
	E_Commerce_Website, Tele_caller_AgentsApplication;
}
