package com.AbstractFactory;

public class AudiTire extends Tire {
	
	public AudiTire() {
		super("audi tire");
	}
}
